let skillsSection = document.querySelector(".skills");
let spans = document.querySelectorAll(".the-progress span");
let countDownDate = new Date("April 18, 2025").getTime();
let box = document.querySelectorAll(".box span.number");
let statsSection = document.querySelector(".stats");
let started = false;


let counter1 = setInterval(() => {
    let dateNow = new Date().getTime();
    let diffTime = countDownDate - dateNow;

    let days = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    let hours = Math.floor(diffTime % (1000 * 60 * 60 * 24) / (1000 * 60 * 60));
    let minutes = Math.floor(diffTime % (1000 * 60 * 60) / (1000 * 60));
    let seconds = Math.floor(diffTime % (1000 * 60) / 1000);

    document.querySelector(".days").innerHTML = days;
    document.querySelector(".hours").innerHTML = hours < 10 ? `0${hours}` : hours;
    document.querySelector(".minutes").innerHTML = minutes < 10 ? `0${minutes}` : minutes;
    document.querySelector(".seconds").innerHTML = seconds < 10 ? `0${seconds}` : seconds;

    if (diffTime < 0) {
        clearInterval(counter1); // Stop the countdown once the date has passed
    }
}, 1000);

// Scroll event handler (for skills section and stats counting)
window.onscroll = function() {
    // Handle skills section animation
    if (window.scrollY >= skillsSection.offsetTop - 500) {
        spans.forEach((span) => {
            span.style.width = span.dataset.width;
        });
    }

    // Handle stats section counting animation
    if (window.scrollY >= statsSection.offsetTop && !started) {
        box.forEach((num) => count(num));
        started = true;
    }
};

function count(el) {
    let goal = el.dataset.goal;
    let counter2 = setInterval(() => {
        el.textContent++;
        if (el.textContent === goal) {
            clearInterval(counter2);
        }
    }, 1000 / goal);
}
